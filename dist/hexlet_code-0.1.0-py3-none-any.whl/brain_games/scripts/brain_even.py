#!/usr/bin/env python3

"""Even game"""

import brain_games.games.even
from brain_games.brain_engine import play


def main():
    play(brain_games.games.even)


if __name__ == '__main__':
    main()
