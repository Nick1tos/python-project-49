### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nick1tos/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Nick1tos/python-project-49/actions)
<a href="https://codeclimate.com/github/Nick1tos/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/aadc353950375c4fea8d/maintainability" /></a>

brain-even
<a href="https://asciinema.org/a/xl47ftufJyRVFAjbBsgqnJbBM" target="_blank"><img src="https://asciinema.org/a/xl47ftufJyRVFAjbBsgqnJbBM.svg" /></a>