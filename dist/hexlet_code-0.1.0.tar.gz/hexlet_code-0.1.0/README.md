### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nick1tos/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Nick1tos/python-project-49/actions)
<a href="https://codeclimate.com/github/Nick1tos/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/aadc353950375c4fea8d/maintainability" /></a>

### **brain-even**
<a href="https://asciinema.org/a/xl47ftufJyRVFAjbBsgqnJbBM" target="_blank"><img src="https://asciinema.org/a/xl47ftufJyRVFAjbBsgqnJbBM.svg" /></a>

### **<span style="color:purple">[brain-calc]</span>**(https://asciinema.org/a/PdNo1wONxWkwqG6RPyzTr35ng) 
<a href="https://asciinema.org/a/PdNo1wONxWkwqG6RPyzTr35ng" target="_blank"><img src="https://asciinema.org/a/PdNo1wONxWkwqG6RPyzTr35ng.svg" /></a>

### **<span style="color:purple">[brain-gcd]</span>**(https://asciinema.org/a/A7yBNuHNgSrKmiUKR4M8ew3D5)
<a href="https://asciinema.org/a/A7yBNuHNgSrKmiUKR4M8ew3D5" target="_blank"><img src="https://asciinema.org/a/A7yBNuHNgSrKmiUKR4M8ew3D5.svg" /></a>

### **<span style="color:purple">[brain-progression]</span>**(https://asciinema.org/a/r9kGAWG5PSXLwjbmFqt7p2jxt)
<a href="https://asciinema.org/a/r9kGAWG5PSXLwjbmFqt7p2jxt" target="_blank"><img src="https://asciinema.org/a/r9kGAWG5PSXLwjbmFqt7p2jxt.svg" /></a>

brain-prime
