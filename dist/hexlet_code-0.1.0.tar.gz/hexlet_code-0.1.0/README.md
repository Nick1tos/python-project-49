### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nick1tos/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Nick1tos/python-project-49/actions)