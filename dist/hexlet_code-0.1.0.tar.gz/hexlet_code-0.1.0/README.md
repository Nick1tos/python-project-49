### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nick1tos/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Nick1tos/python-project-49/actions)
<a href="https://codeclimate.com/github/Nick1tos/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/aadc353950375c4fea8d/maintainability" /></a>

### *[brain-even](https://asciinema.org/a/wlJumQWM5WBTgV4RYZH3DBtCm)
<a href="https://asciinema.org/a/wlJumQWM5WBTgV4RYZH3DBtCm" target="_blank"><img src="https://asciinema.org/a/wlJumQWM5WBTgV4RYZH3DBtCm.svg" /></a>

### *[brain-calc](https://asciinema.org/a/PdNo1wONxWkwqG6RPyzTr35ng)
<a href="https://asciinema.org/a/PdNo1wONxWkwqG6RPyzTr35ng" target="_blank"><img src="https://asciinema.org/a/PdNo1wONxWkwqG6RPyzTr35ng.svg" /></a>

### *[brain-gcd](https://asciinema.org/a/A7yBNuHNgSrKmiUKR4M8ew3D5)
<a href="https://asciinema.org/a/A7yBNuHNgSrKmiUKR4M8ew3D5" target="_blank"><img src="https://asciinema.org/a/A7yBNuHNgSrKmiUKR4M8ew3D5.svg" /></a>

### *[brain-progression](https://asciinema.org/a/r9kGAWG5PSXLwjbmFqt7p2jxt)
<a href="https://asciinema.org/a/r9kGAWG5PSXLwjbmFqt7p2jxt" target="_blank"><img src="https://asciinema.org/a/r9kGAWG5PSXLwjbmFqt7p2jxt.svg" /></a>

### *[brain-prime]()
